package com.voxelbusters.nativeplugins.features.notification.core;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.defines.Keys;
import com.voxelbusters.nativeplugins.utilities.ApplicationUtility;

// This class is to get the launch notification info.
public class ApplicationLauncherFromNotification extends Activity
{
	public static String	launchNotificationData	= "";

	@Override
	protected void onCreate(Bundle paramBundle)
	{
		super.onCreate(paramBundle);

		Intent intent = getIntent();

		launchNotificationData = intent.getStringExtra(Keys.Notification.NOTIFICATION_PAYLOAD);

		launchMainActivity(intent);
		Log.v(CommonDefines.NOTIFICATION_TAG, getIntent().getStringExtra(Keys.Notification.NOTIFICATION_PAYLOAD));//We can save this in prefs and tell the app that with this app got launched.
		finish();
	}

	void launchMainActivity(Intent intent)
	{
		Class<?> launcher = ApplicationUtility.GetMainLauncherActivity(this);
		Log.v(CommonDefines.NOTIFICATION_TAG, "Main Launcher Class : " + launcher);
		Intent newIntent = new Intent(this, launcher);
		newIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
		startActivity(newIntent);
	}
}
