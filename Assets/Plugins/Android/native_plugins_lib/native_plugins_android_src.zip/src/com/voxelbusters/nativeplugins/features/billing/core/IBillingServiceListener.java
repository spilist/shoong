package com.voxelbusters.nativeplugins.features.billing.core;

import java.util.ArrayList;

import com.google.gson.JsonObject;

public interface IBillingServiceListener
{
	void onSetupFinished(Boolean isBillingAvialable);

	void onRequestProductsFinished(ArrayList<JsonObject> productDetails, String error);

	void onTransactionFinished(ArrayList<JsonObject> transactionDetails, String error);

}
