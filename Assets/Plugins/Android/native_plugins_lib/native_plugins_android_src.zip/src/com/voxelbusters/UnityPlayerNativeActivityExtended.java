package com.voxelbusters;

import android.app.Activity;
import android.os.Bundle;

import com.voxelbusters.androidnativeplugin.R;
import com.voxelbusters.nativeplugins.features.webview.WebViewHandler;

public class UnityPlayerNativeActivityExtended extends Activity
{
	public static Activity	Instance;

	@Override
	protected void onCreate(Bundle paramBundle)
	{
		super.onCreate(paramBundle);
		Instance = this;
		setContentView(R.layout.np_progressbar_layout);

		String tag = "test";
		WebViewHandler.getInstance().createNativeWebView(tag, 0, 0, 600, 900);
		WebViewHandler.getInstance().loadRequest("http://www.google.com", tag);
		WebViewHandler.getInstance().showWebViewWithTag(tag);

	}

	@Override
	protected void onDestroy()
	{
		super.onDestroy();
	}

}
