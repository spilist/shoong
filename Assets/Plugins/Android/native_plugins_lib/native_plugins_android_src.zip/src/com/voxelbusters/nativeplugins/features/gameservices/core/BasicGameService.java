package com.voxelbusters.nativeplugins.features.gameservices.core;

import java.util.HashMap;

import android.content.Context;

public class BasicGameService implements IGameServices
{
	public enum eGameServiceState
	{
		NONE, SIGNING_IN, SIGNING_OUT, RESOLVING_ERROR
	}

	protected IGameServicesListener	listener;

	protected eGameServiceState		state;
	protected Context				context;

	public BasicGameService(Context context)
	{
		this.context = context;
		state = eGameServiceState.NONE;
	}

	@Override
	public boolean isAvailable()
	{
		throw new UnsupportedOperationException("Implement in sub class");
	}

	@Override
	public void setListener(IGameServicesListener listener)
	{
		this.listener = listener;
	}

	@Override
	public void signIn()
	{
		state = eGameServiceState.SIGNING_IN;
	}

	@Override
	public void signOut()
	{
		state = eGameServiceState.SIGNING_OUT;
	}

	@Override
	public boolean isSignedIn()
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void reportProgress(String instanceId, String achievementId, int points, boolean immediate)
	{
		throw new UnsupportedOperationException("Implement in sub class");
	}

	@Override
	public void loadAllAchievements()
	{
		throw new UnsupportedOperationException("Implement in sub class");
	}

	@Override
	public void loadUserAchievements()
	{
		throw new UnsupportedOperationException("Implement in sub class");
	}

	@Override
	public void showAchievementsUi()
	{
		throw new UnsupportedOperationException("Implement in sub class");
	}

	@Override
	public void reportScore(String instanceId, String leaderboardId, long score, boolean immediate)

	{
		throw new UnsupportedOperationException("Implement in sub class");
	}

	@Override
	public void showLeaderboardsUi(String leaderboardId, int timeSpan)
	{
		throw new UnsupportedOperationException("Implement in sub class");
	}

	@Override
	public void loadUsers(String instanceId, String[] userIdList)
	{
		throw new UnsupportedOperationException("Implement in sub class");
	}

	@Override
	public void requestLocalPlayerDetails()
	{
		throw new UnsupportedOperationException("Implement in sub class");
	}

	@Override
	public void loadLocalPlayerFriends(boolean forceLoad)
	{
		throw new UnsupportedOperationException("Implement in sub class");
	}

	@Override
	public void loadPlayerCenteredScores(String instanceId, String leaderBoardId, int timeScope, int userScope, int count)
	{
		throw new UnsupportedOperationException("Implement in sub class");
	}

	@Override
	public void loadTopScores(String instanceId, String leaderBoardId, int timeScope, int userScope, int count)
	{
		throw new UnsupportedOperationException("Implement in sub class");
	}

	@Override
	public void loadMoreScrores(String instanceId, String leaderBoardId, int direction, int count)
	{
		throw new UnsupportedOperationException("Implement in sub class");
	}

	@Override
	public void loadProfileImage(String requestId, String uriString)
	{
		throw new UnsupportedOperationException("Implement in sub class");
	}

	@Override
	public HashMap<String, Object> getAchievement(String achievementId)
	{
		return null;
	}

}
