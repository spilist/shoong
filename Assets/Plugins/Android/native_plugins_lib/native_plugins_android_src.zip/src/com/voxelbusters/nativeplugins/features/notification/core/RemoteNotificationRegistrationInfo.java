package com.voxelbusters.nativeplugins.features.notification.core;

public class RemoteNotificationRegistrationInfo
{
	public String	registrationId;
	public String	errorMsg;

}
